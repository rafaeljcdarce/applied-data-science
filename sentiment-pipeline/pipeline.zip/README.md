# Tweet Sentiment Pipeline

## Install

Assumes you are on Linux/Mac and have Python 3.6+

```
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Usage

See `example.ipynb`