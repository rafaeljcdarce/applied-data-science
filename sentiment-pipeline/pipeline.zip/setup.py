import setuptools

setuptools.setup(
    name="sentiment_pipeline",
    packages=["sentiment_pipeline"],
    version="0.0.1",
    python_requires=">=3.6",
)